"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Calendar,
  Clock,
  Users,
  Phone,
  Mail,
  ArrowLeft,
  Search,
  Filter,
  TrendingUp,
  CheckCircle,
  XCircle,
  AlertCircle,
  MoreHorizontal,
  Download,
  Eye,
} from "lucide-react"
import Link from "next/link"
import { format, isToday, isTomorrow, parseISO } from "date-fns"

interface Reservation {
  id: string
  name: string
  email: string
  phone: string
  partySize: string
  time: string
  date: string
  specialRequests: string
  status: string
  createdAt: string
}

export default function AdminPage() {
  const [reservations, setReservations] = useState<Reservation[]>([])
  const [filteredReservations, setFilteredReservations] = useState<Reservation[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [dateFilter, setDateFilter] = useState("all")

  const [currentUserEmail, setCurrentUserEmail] = useState("")
  const [showEmailInput, setShowEmailInput] = useState(false)

  useEffect(() => {
    const savedEmail = localStorage.getItem("currentUserEmail")
    if (savedEmail) {
      setCurrentUserEmail(savedEmail)
    } else {
      setShowEmailInput(true)
    }
  }, [])

  useEffect(() => {
    const stored = localStorage.getItem("reservations")
    if (stored && currentUserEmail) {
      const data = JSON.parse(stored)
      const userReservations = data.filter(
        (reservation) => reservation.email.toLowerCase() === currentUserEmail.toLowerCase(),
      )
      setReservations(userReservations)
      setFilteredReservations(userReservations)
    }
  }, [currentUserEmail])

  useEffect(() => {
    let filtered = reservations

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(
        (reservation) =>
          reservation.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          reservation.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
          reservation.phone.includes(searchTerm),
      )
    }

    // Status filter
    if (statusFilter !== "all") {
      filtered = filtered.filter((reservation) => reservation.status === statusFilter)
    }

    // Date filter
    if (dateFilter !== "all") {
      const now = new Date()
      filtered = filtered.filter((reservation) => {
        const reservationDate = parseISO(reservation.date)
        switch (dateFilter) {
          case "today":
            return isToday(reservationDate)
          case "tomorrow":
            return isTomorrow(reservationDate)
          case "upcoming":
            return reservationDate >= now
          default:
            return true
        }
      })
    }

    setFilteredReservations(filtered)
  }, [reservations, searchTerm, statusFilter, dateFilter])

  const updateReservationStatus = (id: string, newStatus: string) => {
    const updated = reservations.map((reservation) =>
      reservation.id === id ? { ...reservation, status: newStatus } : reservation,
    )
    setReservations(updated)
    localStorage.setItem("reservations", JSON.stringify(updated))
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "bg-green-100 text-green-800 border-green-200"
      case "pending":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "cancelled":
        return "bg-red-100 text-red-800 border-red-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "confirmed":
        return <CheckCircle className="h-4 w-4" />
      case "pending":
        return <AlertCircle className="h-4 w-4" />
      case "cancelled":
        return <XCircle className="h-4 w-4" />
      default:
        return <AlertCircle className="h-4 w-4" />
    }
  }

  const stats = {
    total: reservations.length,
    confirmed: reservations.filter((r) => r.status === "confirmed").length,
    pending: reservations.filter((r) => r.status === "pending").length,
    cancelled: reservations.filter((r) => r.status === "cancelled").length,
    today: reservations.filter((r) => isToday(parseISO(r.date))).length,
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {showEmailInput && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className="w-full max-w-md mx-4">
            <CardHeader>
              <CardTitle>Enter Your Email</CardTitle>
              <CardDescription>Enter your email address to view your personal reservations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Input
                  type="email"
                  placeholder="your@email.com"
                  value={currentUserEmail}
                  onChange={(e) => setCurrentUserEmail(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === "Enter" && currentUserEmail) {
                      localStorage.setItem("currentUserEmail", currentUserEmail)
                      setShowEmailInput(false)
                    }
                  }}
                />
                <Button
                  className="w-full"
                  onClick={() => {
                    if (currentUserEmail) {
                      localStorage.setItem("currentUserEmail", currentUserEmail)
                      setShowEmailInput(false)
                    }
                  }}
                  disabled={!currentUserEmail}
                >
                  View My Reservations
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
      <header className="border-b bg-white/90 backdrop-blur-md shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">My Reservations Dashboard</h1>
              <p className="text-sm text-slate-600">
                Viewing reservations for: <span className="font-medium">{currentUserEmail}</span>
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                localStorage.removeItem("currentUserEmail")
                setCurrentUserEmail("")
                setShowEmailInput(true)
              }}
            >
              Switch User
            </Button>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export My Data
            </Button>
            <Link href="/book">
              <Button size="sm" className="bg-gradient-to-r from-blue-600 to-purple-600">
                New Reservation
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white border-0">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100 text-sm">Total</p>
                  <p className="text-2xl font-bold">{stats.total}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-blue-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white border-0">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100 text-sm">Confirmed</p>
                  <p className="text-2xl font-bold">{stats.confirmed}</p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white border-0">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-yellow-100 text-sm">Pending</p>
                  <p className="text-2xl font-bold">{stats.pending}</p>
                </div>
                <AlertCircle className="h-8 w-8 text-yellow-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-red-500 to-red-600 text-white border-0">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-red-100 text-sm">Cancelled</p>
                  <p className="text-2xl font-bold">{stats.cancelled}</p>
                </div>
                <XCircle className="h-8 w-8 text-red-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white border-0">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-sm">Today</p>
                  <p className="text-2xl font-bold">{stats.today}</p>
                </div>
                <Calendar className="h-8 w-8 text-purple-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              Filters & Search
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Search by name, email, or phone..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="confirmed">Confirmed</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
              <Select value={dateFilter} onValueChange={setDateFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by date" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Dates</SelectItem>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="tomorrow">Tomorrow</SelectItem>
                  <SelectItem value="upcoming">Upcoming</SelectItem>
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                onClick={() => {
                  setSearchTerm("")
                  setStatusFilter("all")
                  setDateFilter("all")
                }}
              >
                Clear Filters
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Reservations List */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>My Reservations ({filteredReservations.length})</span>
              <Button variant="outline" size="sm">
                <Eye className="h-4 w-4 mr-2" />
                View All
              </Button>
            </CardTitle>
            <CardDescription>View and manage your personal reservations</CardDescription>
          </CardHeader>
          <CardContent>
            {filteredReservations.length === 0 ? (
              <div className="text-center py-12">
                <Calendar className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-slate-600 mb-2">No reservations found</h3>
                <p className="text-slate-500">
                  {reservations.length === 0
                    ? "No reservations have been made yet."
                    : "Try adjusting your filters to see more results."}
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredReservations.map((reservation) => (
                  <Card key={reservation.id} className="border-l-4 border-l-blue-500 hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-semibold">
                            {reservation.name.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <h3 className="font-semibold text-lg">{reservation.name}</h3>
                            <p className="text-sm text-slate-600">ID: #{reservation.id}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={`${getStatusColor(reservation.status)} flex items-center gap-1`}>
                            {getStatusIcon(reservation.status)}
                            {reservation.status}
                          </Badge>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
                        <div className="flex items-center gap-2 text-sm">
                          <Calendar className="h-4 w-4 text-slate-500" />
                          <span className="font-medium">{format(parseISO(reservation.date), "EEEE, MMM d, yyyy")}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Clock className="h-4 w-4 text-slate-500" />
                          <span>{reservation.time}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Users className="h-4 w-4 text-slate-500" />
                          <span>
                            {reservation.partySize} {Number.parseInt(reservation.partySize) === 1 ? "person" : "people"}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Mail className="h-4 w-4 text-slate-500" />
                          <span className="truncate">{reservation.email}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Phone className="h-4 w-4 text-slate-500" />
                          <span>{reservation.phone}</span>
                        </div>
                      </div>

                      {reservation.specialRequests && (
                        <div className="bg-slate-50 p-3 rounded-lg mb-4">
                          <p className="text-sm font-medium text-slate-700 mb-1">Special Requests:</p>
                          <p className="text-sm text-slate-600">{reservation.specialRequests}</p>
                        </div>
                      )}

                      <div className="flex justify-between items-center">
                        <div className="text-xs text-slate-500">
                          Created: {format(parseISO(reservation.createdAt), "MMM d, yyyy 'at' h:mm a")}
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline">
                            Contact Support
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
