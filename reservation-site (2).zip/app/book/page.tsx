"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarIcon, ArrowLeft, Clock, Users, Mail, Phone, MessageSquare } from "lucide-react"
import { format } from "date-fns"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function BookingPage() {
  const [date, setDate] = useState<Date>()
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    partySize: "",
    time: "",
    specialRequests: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const router = useRouter()

  const timeSlots = ["5:00 PM", "5:30 PM", "6:00 PM", "6:30 PM", "7:00 PM", "7:30 PM", "8:00 PM", "8:30 PM", "9:00 PM"]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Store reservation in localStorage for demo purposes
    const reservation = {
      id: Date.now().toString(),
      ...formData,
      date: date?.toISOString(),
      status: "pending",
      createdAt: new Date().toISOString(),
    }

    const existingReservations = JSON.parse(localStorage.getItem("reservations") || "[]")
    localStorage.setItem("reservations", JSON.stringify([...existingReservations, reservation]))

    setIsSubmitting(false)
    router.push("/confirmation")
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <header className="border-b bg-white/90 backdrop-blur-md shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="hover:bg-blue-50">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Make a Reservation
            </h1>
            <p className="text-sm text-slate-600">Book your perfect dining experience</p>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Form */}
            <div className="lg:col-span-2">
              <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
                <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-lg">
                  <CardTitle className="text-2xl">Book Your Table</CardTitle>
                  <CardDescription className="text-blue-100">
                    Fill out the form below to make your reservation. We'll confirm your booking shortly.
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-8">
                  <form onSubmit={handleSubmit} className="space-y-8">
                    {/* Personal Information */}
                    <div className="space-y-6">
                      <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
                        <Users className="h-5 w-5 text-blue-600" />
                        Personal Information
                      </h3>
                      <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="name" className="text-slate-700 font-medium">
                            Full Name *
                          </Label>
                          <Input
                            id="name"
                            value={formData.name}
                            onChange={(e) => handleInputChange("name", e.target.value)}
                            placeholder="Enter your full name"
                            className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="email" className="text-slate-700 font-medium flex items-center gap-2">
                            <Mail className="h-4 w-4" />
                            Email *
                          </Label>
                          <Input
                            id="email"
                            type="email"
                            value={formData.email}
                            onChange={(e) => handleInputChange("email", e.target.value)}
                            placeholder="your@email.com"
                            className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                            required
                          />
                        </div>
                      </div>
                      <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="phone" className="text-slate-700 font-medium flex items-center gap-2">
                            <Phone className="h-4 w-4" />
                            Phone Number *
                          </Label>
                          <Input
                            id="phone"
                            type="tel"
                            value={formData.phone}
                            onChange={(e) => handleInputChange("phone", e.target.value)}
                            placeholder="(555) 123-4567"
                            className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="partySize" className="text-slate-700 font-medium">
                            Party Size *
                          </Label>
                          <Select
                            value={formData.partySize}
                            onValueChange={(value) => handleInputChange("partySize", value)}
                          >
                            <SelectTrigger className="border-slate-200 focus:border-blue-500 focus:ring-blue-500">
                              <SelectValue placeholder="Select party size" />
                            </SelectTrigger>
                            <SelectContent>
                              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((size) => (
                                <SelectItem key={size} value={size.toString()}>
                                  {size} {size === 1 ? "person" : "people"}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>

                    {/* Reservation Details */}
                    <div className="space-y-6">
                      <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
                        <Clock className="h-5 w-5 text-blue-600" />
                        Reservation Details
                      </h3>
                      <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label className="text-slate-700 font-medium">Reservation Date *</Label>
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button
                                variant="outline"
                                className="w-full justify-start text-left font-normal border-slate-200 hover:bg-blue-50"
                              >
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {date ? format(date, "PPP") : "Pick a date"}
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0">
                              <Calendar
                                mode="single"
                                selected={date}
                                onSelect={setDate}
                                disabled={(date) => date < new Date()}
                              />
                            </PopoverContent>
                          </Popover>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="time" className="text-slate-700 font-medium">
                            Preferred Time *
                          </Label>
                          <Select value={formData.time} onValueChange={(value) => handleInputChange("time", value)}>
                            <SelectTrigger className="border-slate-200 focus:border-blue-500 focus:ring-blue-500">
                              <SelectValue placeholder="Select time" />
                            </SelectTrigger>
                            <SelectContent>
                              {timeSlots.map((time) => (
                                <SelectItem key={time} value={time}>
                                  {time}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>

                    {/* Special Requests */}
                    <div className="space-y-4">
                      <Label htmlFor="requests" className="text-slate-700 font-medium flex items-center gap-2">
                        <MessageSquare className="h-4 w-4" />
                        Special Requests
                      </Label>
                      <Textarea
                        id="requests"
                        value={formData.specialRequests}
                        onChange={(e) => handleInputChange("specialRequests", e.target.value)}
                        placeholder="Any special dietary requirements, celebrations, or seating preferences..."
                        rows={4}
                        className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                      />
                    </div>

                    <Button
                      type="submit"
                      className="w-full py-6 text-lg bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-lg hover:shadow-xl transition-all duration-300"
                      disabled={
                        isSubmitting ||
                        !date ||
                        !formData.name ||
                        !formData.email ||
                        !formData.phone ||
                        !formData.partySize ||
                        !formData.time
                      }
                    >
                      {isSubmitting ? (
                        <div className="flex items-center gap-2">
                          <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          Processing Reservation...
                        </div>
                      ) : (
                        "Confirm Reservation"
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <Card className="shadow-lg border-0 bg-gradient-to-br from-blue-600 to-purple-600 text-white">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4">Reservation Summary</h3>
                  <div className="space-y-3 text-blue-100">
                    <div className="flex justify-between">
                      <span>Date:</span>
                      <span className="text-white font-medium">
                        {date ? format(date, "MMM d, yyyy") : "Not selected"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Time:</span>
                      <span className="text-white font-medium">{formData.time || "Not selected"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Party Size:</span>
                      <span className="text-white font-medium">
                        {formData.partySize
                          ? `${formData.partySize} ${Number.parseInt(formData.partySize) === 1 ? "person" : "people"}`
                          : "Not selected"}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-lg">
                <CardContent className="p-6">
                  <h3 className="font-bold mb-4 text-slate-900">Important Information</h3>
                  <ul className="space-y-2 text-sm text-slate-600">
                    <li>• Please arrive 10 minutes early</li>
                    <li>• Reservations are held for 15 minutes</li>
                    <li>• Large parties (8+) may require a deposit</li>
                    <li>• Cancellations must be made 2 hours in advance</li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="shadow-lg bg-green-50 border-green-200">
                <CardContent className="p-6">
                  <h3 className="font-bold mb-2 text-green-800">Need Help?</h3>
                  <p className="text-sm text-green-700 mb-3">Our team is here to assist you with your reservation.</p>
                  <Button variant="outline" className="w-full border-green-300 text-green-700 hover:bg-green-100">
                    <Phone className="h-4 w-4 mr-2" />
                    Call (555) 123-4567
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
