import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, Calendar } from "lucide-react"
import Link from "next/link"

export default function ConfirmationPage() {
  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
          <CardTitle className="text-2xl text-green-600">Reservation Confirmed!</CardTitle>
          <CardDescription>
            Your table has been successfully reserved. You'll receive a confirmation email shortly.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-green-50 p-4 rounded-lg space-y-3">
            <div className="flex items-center gap-3">
              <Calendar className="h-5 w-5 text-green-600" />
              <span className="font-medium">Reservation Details</span>
            </div>
            <div className="text-sm text-slate-600 space-y-1">
              <p>• Confirmation will be sent to your email</p>
              <p>• Please arrive 10 minutes early</p>
              <p>• Contact us if you need to make changes</p>
            </div>
          </div>

          <div className="flex gap-2">
            <Link href="/" className="flex-1">
              <Button variant="outline" className="w-full">
                Back to Home
              </Button>
            </Link>
            <Link href="/reservations" className="flex-1">
              <Button className="w-full">View Reservations</Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
