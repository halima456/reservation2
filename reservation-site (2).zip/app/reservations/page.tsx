"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, Users, Phone, Mail, ArrowLeft, Plus } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"

interface Reservation {
  id: string
  name: string
  email: string
  phone: string
  partySize: string
  time: string
  date: string
  specialRequests: string
  status: string
  createdAt: string
}

export default function ReservationsPage() {
  const [reservations, setReservations] = useState<Reservation[]>([])

  useEffect(() => {
    const stored = localStorage.getItem("reservations")
    if (stored) {
      setReservations(JSON.parse(stored))
    }
  }, [])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "bg-green-100 text-green-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="border-b bg-white">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-slate-900">Your Reservations</h1>
          </div>
          <Link href="/book">
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Reservation
            </Button>
          </Link>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {reservations.length === 0 ? (
          <Card className="max-w-md mx-auto text-center">
            <CardHeader>
              <CardTitle>No Reservations Yet</CardTitle>
              <CardDescription>You haven't made any reservations yet. Book your first table now!</CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/book">
                <Button>Make Your First Reservation</Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-6 max-w-4xl mx-auto">
            {reservations.map((reservation) => (
              <Card key={reservation.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        {reservation.name}
                        <Badge className={getStatusColor(reservation.status)}>{reservation.status}</Badge>
                      </CardTitle>
                      <CardDescription>Reservation #{reservation.id}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-slate-500" />
                        <span>{format(new Date(reservation.date), "EEEE, MMMM d, yyyy")}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-slate-500" />
                        <span>{reservation.time}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-slate-500" />
                        <span>
                          {reservation.partySize} {Number.parseInt(reservation.partySize) === 1 ? "person" : "people"}
                        </span>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <Mail className="h-4 w-4 text-slate-500" />
                        <span className="text-sm">{reservation.email}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Phone className="h-4 w-4 text-slate-500" />
                        <span className="text-sm">{reservation.phone}</span>
                      </div>
                      {reservation.specialRequests && (
                        <div className="text-sm">
                          <span className="font-medium">Special Requests:</span>
                          <p className="text-slate-600 mt-1">{reservation.specialRequests}</p>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
